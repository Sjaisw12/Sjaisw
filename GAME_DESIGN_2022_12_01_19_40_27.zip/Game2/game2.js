let startbutton2;
let score4;
 let game2x1 = 200
let game2x2 = 290
let game2y1 = 100
 let game2y2 = 190
  let game3x1 = 100;
  let game3x2 = 190;
  let game3y1 = 300;
  let game3y2 = 390;
function game2Preload(){
  
}
let beentoScreen2 = false;
function game2Setup(){
  beentoScreen2 = true;
  background('blue');
  currentActivity = 3;
  
  // Hide the Activity 2 button, show all the other buttons
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
 
  
  startbutton = createButton("Start");
  startbutton.position(200,200);
  startbutton.mousePressed(()=> updateChoice(3));
    createCanvas(400,395);
  background("lightgreen");
  textSize(20);
    stroke('black');
   strokeWeight(5);
  circle(100,200,100);
  square(200,100,90);
  square(100,300,90);
  let game2x1 = 200
  let game2x2 = 290
  let game2y1 = 100
  let game2y2 = 190
  
  let game3x1 = 100;
  let game3x2 = 190;
  let game3y1 = 300;
  let game3y2 = 390;
  circle(300,300,100);
   stroke('black');
   strokeWeight(10);
  fill('red');
  text("CutArt",170,40);
}

function game2Draw(){
  startbutton.hide();
  
  if (mouseIsPressed) {
  let cx101 = 100;
  let cy101 = 200;
  let a1 = pow((cx101-mouseX),2);
  let b1 = pow((cy101-mouseY),2);
  let r1 = 50;
  let dist = sqrt(a1+b1);
  
   let cx1001 = 300;
  let cy1001 = 300;
  let a11 = pow((cx1001-mouseX),2);
  let b11 = pow((cy1001-mouseY),2);
  let r11 = 50;
  let dist1 = sqrt(a11+b11);
  let inSquare = false;
     
    

     if(dist <= r1 || dist1 <= r11|| mouseX >= game2x1 && mouseX <= game2x2 && mouseY >= game2y1 && mouseY <= game2y2 || mouseX >= game3x1 && mouseX <= game3x2 && mouseY >= game3y1 && mouseY <= game3y2 ){
       color = "blue";
       }
    else{
      color = "red";
    }
    
    stroke(color);
    circle(mouseX, mouseY, 4);
    game2Check();
  }
}

function game2Check()
{
  
  
}




