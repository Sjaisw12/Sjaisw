let balloons = [];
let score = 0; 
let start = 0;
let bg;
let startbutton;
function game1Preload(){
 
 
}
let beenToScreen1 = false;
function game1Setup(){
  beenToScreen1 = true;
  console.log('here');
  //createCanvas(400, 395);
  bg = loadImage('image121212.jpeg');
  //addBalloons(1);
  createCanvas(400, 395);
  background(bg);
 // currentActivity = 1;
  //text('Click Anywhere to Start',200,100);
  score = 0; 
  // Hide the Game 1 button, show all the other navigation buttons
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  
  startbutton = createButton("Start");
  startbutton.position(200,200);
  startbutton.mousePressed(()=> updateChoice(2));
  

}

function game1Draw(){
  startbutton.hide();
background(bg);  
   textSize(20);
  stroke('red');
  strokeWeight(10);
  fill('pink');
  text('aimPOP', 160, 60);
   //background('skyblue');
  //addBalloons(1);
  // Display and move all balloons
  
 for (let balloon of balloons) {
   
    text('Score : ' + score, 280,50);
  	balloon.display();
    balloon.move();
  }
  
  // Add 5 more balloons every 40 frames
  if (frameCount % 100 == 0) {
    addBalloons(2);
  }
  
    
}

function mouseClicked() {
  for (let balloon of balloons) {
  	balloon.burst();
  }
  
    return true;
}

function hidebuttonsgame1(){
  startbutton.hide();
  print('button hidden');
}
 

function addBalloons(num) {
  // Add num balloons to the balloons array
  for (let count = 0; count < num; count++) {
  	let tempBalloon = new Balloon(random(width), random(height, height + 50), 'pink');
    balloons.push(tempBalloon);
  }
}


class Balloon {
  constructor(x, y, colour) {
    this.x = x;
    this.y = y;
    this.colour = colour;
    this.size = 50;
    this.bursted = false;
  }
  
  display() {
    if (!this.bursted) {
      fill(this.colour);
      ellipse(this.x, this.y, this.size);
      line(this.x, this.y + this.size/2, this.x, this.y + 2 * this.size);
    }
  }

  move() {
    this.y -= 1;
  }
  
  burst() {
    let distance = dist(this.x, this.y, mouseX, mouseY);
    if (distance <= this.size/2) {
      this.bursted = true;
      score++;
    }

  }
}
