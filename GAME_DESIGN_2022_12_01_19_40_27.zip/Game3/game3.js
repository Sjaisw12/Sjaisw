let exercise3x = 200;
let exercise3y = 200;
let startbutton3;
//BOX MAker;
let bx = 10;
let by = 10;
let boxSize = 10;
let overBox = false;
let locked = false;
let xOffset = 0.0;
let yOffset = 0.0;

let bx2 = 10;
let by2 = 10;
let boxSize2 = 10;
let overBox2 = false;
let locked2 = false;
let xOffset2 = 0.0;
let yOffset2 = 0.0;

let bx3 = 10;
let by3 = 10;
let boxSize3 = 10;
let overBox3 = false;
let locked3 = false;
let xOffset3 = 0.0;
let yOffset3 = 0.0;

let bx4 = 10;
let by4 = 10;
let boxSize4 = 10;
let overBox4 = false;
let locked4 = false;
let xOffset4 = 0.0;
let yOffset4 = 0.0;

let bx5 = 10;
let by5 = 10;
let boxSize5 = 10;
let overBox5 = false;
let locked5 = false;
let xOffset5 = 0.0;
let yOffset5 = 0.0;
let score3 = 0;
let bx6 = 10;
let by6 = 10;
let boxSize6 = 10;
let overBox6 = false;
let locked6 = false;
let xOffset6 = 0.0;
let yOffset6 = 0.0;

let bx7 = 10;
let by7 = 10;
let boxSize7 = 10;
let overBox7 = false;
let locked7 = false;
let xOffset7 = 0.0;
let yOffset7 = 0.0;

let bx8 = 10;
let by8 = 10;
let boxSize8 = 10;
let overBox8 = false;
let locked8 = false;
let xOffset8 = 0.0;
let yOffset8 = 0.0;

let bx9 = 10;
let by9 = 10;
let boxSize9 = 10;
let overBox9 = false;
let locked9 = false;
let xOffset9 = 0.0;
let yOffset9 = 0.0;

let bx10 = 10;
let by10 = 10;
let boxSize10 = 10;
let overBox10 = false;
let locked10 = false;
let xOffset10 = 0.0;
let yOffset10 = 0.0;

let beenToScreen3 = false;
function game3Preload() {}

function game3Setup() {
  beenToScreen3 = true;
  background("lightblue");
  stroke("black");
  currentActivity = 4;
  score3 = 0;
  //text("score = " + score);
  // Hide the Activity 3 button, show all the other buttons
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  textSize("20");

  fill("red");
  text("Rules", 170, 60);
  textSize("10");
  fill("black");
  text(
    "Color square boxes should be placed in the correct color circles.",
    15,
    100
  );
  text(
    "Place the color square boxes in the appropriate circle to earn one points.",
    15,
    120
  );
  text(
    "Placing a square in the wrong color circle will result in no point.",
    15,
    140
  );
  fill('red');
  text("click submit button only when you have placed all the boxes", 15, 160);
  //BOX 1 setup
  bx = width / 2.0;
  by = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(0);
  //BOX 2 setup
  bx2 = width / 2.7;
  by2 = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(2);
  //Box 3 setup
  bx3 = width / 4.55;
  by3 = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(2);

  bx4 = width / 6;
  by4 = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(2);

  bx5 = width / 3.5;
  by5 = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(2);

  bx6 = width / 1.5;
  by6 = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(2);

  bx7 = width / 1.75;
  by7 = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(2);

  bx8 = width / 1.2;
  by8 = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(2);

  bx9 = width / 1.05;
  by9 = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(2);

  bx10 = width / 1.35;
  by10 = height / 2.0;
  rectMode(RADIUS);
  strokeWeight(2);

  startbutton3 = createButton("Start");
  startbutton3.position(170, 200);
  startbutton3.mousePressed(() => updateChoice(4));

  submitbutton = createButton("Submit");
  submitbutton.position(305, 360);
  finalscore();
  submitbutton.mousePressed(() => finalscore());
}
function finalscore() {
  squareCheck();
  squareCheck2();
  squareCheck6();
  squareCheck7();
  squareCheck8();
  squareCheck9();
  squareCheck10();
  squareCheck11();
  squareCheck12();
  squareCheck14();
}
function squareCheck() {
  let cx = 100;
  let cy = 100;
  let a = pow(cx - bx, 2);
  let b = pow(cy - by, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
    return true;
  }
  return false;
}
function squareCheck10() {
  let cx = 100;
  let cy = 100;
  let a = pow(cx - bx8, 2);
  let b = pow(cy - by8, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
  }
}
function squareCheck11() {
  let cx = 100;
  let cy = 100;
  let a = pow(cx - bx10, 2);
  let b = pow(cy - by10, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
  }
}
function squareCheck2() {
  let cx = 300;
  let cy = 300;
  let a = pow(cx - bx2, 2);
  let b = pow(cy - by2, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
  }
}
function squareCheck12() {
  let cx = 300;
  let cy = 300;
  let a = pow(cx - bx6, 2);
  let b = pow(cy - by6, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
  }
}

function squareCheck6() {
  let cx = 100;
  let cy = 320;
  let a = pow(cx - bx7, 2);
  let b = pow(cy - by7, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
  }
}
function squareCheck7() {
  let cx = 100;
  let cy = 320;
  let a = pow(cx - bx9, 2);
  let b = pow(cy - by9, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
  }
}
function squareCheck14() {
  let cx = 100;
  let cy = 320;
  let a = pow(cx - bx3, 2);
  let b = pow(cy - by3, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
  }
}
function squareCheck8() {
  let cx = 300;
  let cy = 50;
  let a = pow(cx - bx4, 2);
  let b = pow(cy - by4, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
  }
}
function squareCheck9() {
  let cx = 300;
  let cy = 50;
  let a = pow(cx - bx5, 2);
  let b = pow(cy - by5, 2);
  let r = 50;
  let dist = sqrt(a + b);

  if (dist < r) {
    score3 += 1;
    text("correct!", 200, 200);
  }
}
function game3Draw() {
  choice = 4;
  //text('Score is ' + score3, 100,200);
  startbutton3.hide();
  background(400, 395);
  background("lightgreen");
  textSize(20);
  stroke("black");
  strokeWeight("2");
  fill("red");
  text("sortUP", 160, 40);
  text("Score :" + score3, 160, 70);
  fill("green");
  circle(100, 100, 100);

  fill("yellow");
  circle(300, 300, 100);

  fill("blue");
  circle(300, 100, 100);

  fill("pink");
  circle(100, 300, 100);
  // Test if the cursor is over the box
  //BOX NUMBER 1 GAMEPLAY
  if (
    mouseX > bx - boxSize &&
    mouseX < bx + boxSize &&
    mouseY > by - boxSize &&
    mouseY < by + boxSize
  ) {
    overBox = true;
    if (!locked) {
      stroke(" black");
      fill(" green");
      //squareCheck();
    }
  } else {
    stroke("green");
    fill(" green");
    overBox = false;
  }
  //squareCheck();

  //BOX NUMBER 2 GAMEPLAY
  if (
    mouseX > bx2 - boxSize2 &&
    mouseX < bx2 + boxSize2 &&
    mouseY > by2 - boxSize2 &&
    mouseY < by2 + boxSize2
  ) {
    overBox2 = true;
    if (!locked) {
      stroke(255);
      fill(244, 122, 158);
    }
  } else {
    stroke(156, 39, 176);
    fill(244, 122, 158);
    overBox2 = false;
  }
  //BOX NUMBER 3 GAME PLAY
  if (
    mouseX > bx3 - boxSize3 &&
    mouseX < bx3 + boxSize3 &&
    mouseY > by3 - boxSize3 &&
    mouseY < by3 + boxSize3
  ) {
    overBox3 = true;
    if (!locked3) {
      stroke(255);
      fill(244, 122, 158);
    }
  } else {
    stroke(156, 39, 176);
    fill(244, 122, 158);
    overBox3 = false;
  }
  //BOX 4
  if (
    mouseX > bx4 - boxSize4 &&
    mouseX < bx4 + boxSize4 &&
    mouseY > by4 - boxSize4 &&
    mouseY < by4 + boxSize4
  ) {
    overBox4 = true;
    if (!locked4) {
      stroke(255);
      fill(244, 122, 158);
    }
  } else {
    stroke(156, 39, 176);
    fill(244, 122, 158);
    overBox4 = false;
  }

  //BOX 5
  if (
    mouseX > bx5 - boxSize5 &&
    mouseX < bx5 + boxSize5 &&
    mouseY > by5 - boxSize5 &&
    mouseY < by5 + boxSize5
  ) {
    overBox5 = true;
    if (!locked5) {
      stroke(255);
      fill(244, 122, 158);
    }
  } else {
    stroke(156, 39, 176);
    fill(244, 122, 158);
    overBox5 = false;
  }
  //BOX NUMBER 6
  if (
    mouseX > bx6 - boxSize6 &&
    mouseX < bx6 + boxSize6 &&
    mouseY > by6 - boxSize6 &&
    mouseY < by6 + boxSize6
  ) {
    overBox6 = true;
    if (!locked6) {
      stroke(255);
      fill(244, 122, 158);
    }
  } else {
    stroke(156, 39, 176);
    fill(244, 122, 158);
    overBox6 = false;
  }
  //BOX NUMBER 7
  if (
    mouseX > bx7 - boxSize7 &&
    mouseX < bx7 + boxSize7 &&
    mouseY > by7 - boxSize7 &&
    mouseY < by7 + boxSize7
  ) {
    overBox7 = true;
    if (!locked7) {
      stroke(255);
      fill(244, 122, 158);
    }
  } else {
    stroke(156, 39, 176);
    fill(244, 122, 158);
    overBox7 = false;
  }
  //BOX NUMBER 8
  if (
    mouseX > bx8 - boxSize8 &&
    mouseX < bx8 + boxSize8 &&
    mouseY > by8 - boxSize8 &&
    mouseY < by8 + boxSize8
  ) {
    overBox8 = true;
    if (!locked8) {
      stroke(255);
      fill(244, 122, 158);
    }
  } else {
    stroke(156, 39, 176);
    fill(244, 122, 158);
    overBox8 = false;
  }
  //BOX NUMBER 9
  if (
    mouseX > bx9 - boxSize9 &&
    mouseX < bx9 + boxSize9 &&
    mouseY > by9 - boxSize9 &&
    mouseY < by9 + boxSize9
  ) {
    overBox9 = true;
    if (!locked9) {
      stroke(255);
      fill(244, 122, 158);
    }
  } else {
    stroke(156, 39, 176);
    fill(244, 122, 158);
    overBox9 = false;
  }
  //BOX NUMBER 10
  if (
    mouseX > bx10 - boxSize10 &&
    mouseX < bx10 + boxSize10 &&
    mouseY > by10 - boxSize10 &&
    mouseY < by10 + boxSize10
  ) {
    overBox10 = true;
    if (!locked10) {
      stroke(255);
      fill(244, 122, 158);
    }
  } else {
    stroke(156, 39, 176);
    fill(244, 122, 158);
    overBox10 = false;
  }

  // DRAW THE UPDATED BOXES;
  fill("green");
  rect(bx, by, boxSize, boxSize);
  fill("yellow");
  rect(bx2, by2, boxSize2, boxSize2);
  fill("pink");
  rect(bx3, by3, boxSize3, boxSize3);
  fill("blue");
  rect(bx4, by4, boxSize4, boxSize4);
  fill("blue");
  rect(bx5, by5, boxSize5, boxSize5);
  fill("yellow");
  rect(bx6, by6, boxSize6, boxSize6);
  fill("pink");
  rect(bx7, by7, boxSize7, boxSize7);
  fill("green");
  rect(bx8, by8, boxSize8, boxSize8);
  fill("pink");
  rect(bx9, by9, boxSize9, boxSize9);
  fill("green");
  rect(bx10, by10, boxSize10, boxSize10);
  stroke("black");
  fill(" rgb(19,243,19)");
}

function mousePressed() {
  if (overBox) {
    locked = true;
    fill("green");
  } else {
    locked = false;
  }
  xOffset = mouseX - bx;
  yOffset = mouseY - by;
  //MOUSE PRESSED FOR BOX 2
  if (overBox2) {
    locked2 = true;
    fill(255, 255, 255);
  } else {
    locked2 = false;
  }
  xOffset2 = mouseX - bx2;
  yOffset2 = mouseY - by2;
  //MOUSEPRESSED FOR BOX 3
  if (overBox3) {
    locked3 = true;
    fill(255, 255, 255);
  } else {
    locked3 = false;
  }
  xOffset3 = mouseX - bx3;
  yOffset3 = mouseY - by3;
  //BOX 4 MOUSE
  if (overBox4) {
    locked4 = true;
    fill(255, 255, 255);
  } else {
    locked4 = false;
  }
  xOffset4 = mouseX - bx4;
  yOffset4 = mouseY - by4;

  //BOX 5
  if (overBox5) {
    locked5 = true;
    fill(255, 255, 255);
  } else {
    locked5 = false;
  }
  xOffset5 = mouseX - bx5;
  yOffset5 = mouseY - by5;

  //BOX 6
  if (overBox6) {
    locked6 = true;
    fill(255, 255, 255);
  } else {
    locked6 = false;
  }
  xOffset6 = mouseX - bx6;
  yOffset6 = mouseY - by6;

  //BOX 7
  if (overBox7) {
    locked7 = true;
    fill(255, 255, 255);
  } else {
    locked7 = false;
  }
  xOffset7 = mouseX - bx7;
  yOffset7 = mouseY - by7;

  //box number 8
  if (overBox8) {
    locked8 = true;
    fill(255, 255, 255);
  } else {
    locked8 = false;
  }
  xOffset8 = mouseX - bx8;
  yOffset8 = mouseY - by8;

  //BOX NUMBER 9
  if (overBox9) {
    locked9 = true;
    fill(255, 255, 255);
  } else {
    locked9 = false;
  }
  xOffset9 = mouseX - bx9;
  yOffset9 = mouseY - by9;
  //BOX NUMBER 10
  if (overBox10) {
    locked10 = true;
    fill(255, 255, 255);
  } else {
    locked10 = false;
  }
  xOffset10 = mouseX - bx10;
  yOffset10 = mouseY - by10;
}

function mouseDragged() {
  //MOUSE LOCKED ON 1
  if (locked) {
    bx = mouseX - xOffset;
    by = mouseY - yOffset;
  }
  //MOUSE LOcked on 2
  if (locked2) {
    bx2 = mouseX - xOffset2;
    by2 = mouseY - yOffset2;
  }
  //MOUSE LOCKED ON 3
  if (locked3) {
    bx3 = mouseX - xOffset3;
    by3 = mouseY - yOffset3;
  }
  //MOUSE 4
  if (locked4) {
    bx4 = mouseX - xOffset4;
    by4 = mouseY - yOffset4;
  }
  //MOUSe 5
  if (locked5) {
    bx5 = mouseX - xOffset5;
    by5 = mouseY - yOffset5;
  }
  //BOX MOUSE 6
  if (locked6) {
    bx6 = mouseX - xOffset6;
    by6 = mouseY - yOffset6;
  }
  //MOUSE LOCKED ON 7
  if (locked7) {
    bx7 = mouseX - xOffset7;
    by7 = mouseY - yOffset7;
  }
  //MOUSE ON 8
  if (locked8) {
    bx8 = mouseX - xOffset8;
    by8 = mouseY - yOffset8;
  }
  //MOUSE 9
  if (locked9) {
    bx9 = mouseX - xOffset9;
    by9 = mouseY - yOffset9;
  }
  //MOUSE 10
  if (locked10) {
    bx10 = mouseX - xOffset10;
    by10 = mouseY - yOffset10;
  }
}

function mouseReleased() {
  locked = false;
  locked2 = false;
  locked3 = false;
  locked4 = false;
  locked5 = false;
  locked6 = false;
  locked7 = false;
  locked8 = false;
  locked9 = false;
  locked10 = false;
}
