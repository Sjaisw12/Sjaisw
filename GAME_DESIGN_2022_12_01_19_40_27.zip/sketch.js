let homepage;
let currentActivity = 0;
let menuButton, game1Button, game2Button, game3Button;
let gig;
function preload(){
  game1Preload();
  game2Preload();
  game3Preload();
  homepage = loadImage('homepage (1).jpg');
}

function switchToMM(){
  //homepage = loadImage('homepage.jpeg');
  background(homepage);
  currentActivity = 0;
  //fill('red');
  //text("HOMEPAGE",200,200);
  // Hide the home page button, show the activity buttons
  menuButton.hide();
  game1Button.show();
  game2Button.show();
  game3Button.show();
}

function setup() {
  
 
  // homepage = loadImage('homepage.jpeg');
  // background(homepage);
  createCanvas(400, 395);
  background(homepage);
  background(homepage);
  //background();
  menuButton = createButton('Home Page');
  menuButton.position(0, 0);
  menuButton.mousePressed(()=>{
    choice=0;
    
    if(beenToScreen3){
        startbutton3.hide();
        submitbutton.hide();
        beenToScreen3 = false;
    }
    if(beenToScreen1){
        startbutton.hide();
        beenToScreen1 = false;
    }
    if(beentoScreen2){
        startbutton.hide();
        beenToScreen2 = false;
    }
    switchToMM();
                              });
  menuButton.hide();
  
  game1Button = createButton('aimPOP');
  game1Button.position(75, 253);
  game1Button.mousePressed(game1Setup);
  game1Button.show();
  
  game2Button = createButton('cutART');
  game2Button.position(170, 253);
  game2Button.mousePressed(game2Setup);
  game2Button.show();
  
  game3Button = createButton('sortUP');
  game3Button.position(250, 253);
  game3Button.mousePressed(game3Setup);
  game3Button.show();
  

}



let choice = 0;
function draw(){
  switch(choice){
    case 0:
      break;
    case 2:
      game1Draw();
      break;
      case 3: 
      game2Draw();
      break;
      case 4:
      game3Draw();
      break; 

  }
}
  
function updateChoice(newVal){
  choice = newVal;
}
  



function mainMenu(){
  background('rgb(173,220,12)');
  
  fill('black');
  text('Select a Game!', 170, 100);
}

